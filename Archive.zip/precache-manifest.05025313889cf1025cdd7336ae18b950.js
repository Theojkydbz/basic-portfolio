self.__precacheManifest = [
  {
    "revision": "e508b8a505948f722245",
    "url": "/js/chunk-4d702a26.868a3484.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "cb2ff4a21f40499e56ef",
    "url": "/js/chunk-vendors.8cdde8da.js"
  },
  {
    "revision": "350046796036325499ef",
    "url": "/js/chunk-2d0c53b2.037b9b30.js"
  },
  {
    "revision": "f0a658602275f2136820",
    "url": "/js/chunk-2d0b341c.c0d097fc.js"
  },
  {
    "revision": "18deb9e3a080537ac43f",
    "url": "/js/app.80f28efe.js"
  },
  {
    "revision": "7d480cd60448916f8bd13cfe26f7c4fb",
    "url": "/index.html"
  },
  {
    "revision": "c2b53ddec53d440786c8b95d518f5b34",
    "url": "/img/cover.c2b53dde.png"
  },
  {
    "revision": "38d0fde6657aebcc614b8b7b4a7787fa",
    "url": "/img/Illustration.38d0fde6.svg"
  },
  {
    "revision": "e508b8a505948f722245",
    "url": "/css/chunk-4d702a26.e79c3c0e.css"
  },
  {
    "revision": "18deb9e3a080537ac43f",
    "url": "/css/app.0fa0ba0d.css"
  }
];